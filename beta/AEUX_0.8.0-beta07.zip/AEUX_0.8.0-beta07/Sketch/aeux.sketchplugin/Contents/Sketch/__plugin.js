var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/plugin.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@skpm/promise/index.js":
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),

/***/ "./node_modules/mocha-js-delegate/index.js":
/*!*************************************************!*\
  !*** ./node_modules/mocha-js-delegate/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* globals MOClassDescription, NSObject, NSSelectorFromString, NSClassFromString, MOPropertyDescription */

module.exports = function MochaDelegate(definition, superclass) {
  var uniqueClassName =
    'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString()

  var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(
    uniqueClassName,
    superclass || NSObject
  )

  // Storage
  var handlers = {}
  var ivars = {}

  // Define an instance method
  function setHandlerForSelector(selectorString, func) {
    var handlerHasBeenSet = selectorString in handlers
    var selector = NSSelectorFromString(selectorString)

    handlers[selectorString] = func

    /*
      For some reason, Mocha acts weird about arguments: https://github.com/logancollins/Mocha/issues/28
      We have to basically create a dynamic handler with a likewise dynamic number of predefined arguments.
    */
    if (!handlerHasBeenSet) {
      var args = []
      var regex = /:/g
      while (regex.exec(selectorString)) {
        args.push('arg' + args.length)
      }

      // eslint-disable-next-line no-eval
      var dynamicFunction = eval(
        '(function (' +
          args.join(', ') +
          ') { return handlers[selectorString].apply(this, arguments); })'
      )

      delegateClassDesc.addInstanceMethodWithSelector_function(
        selector,
        dynamicFunction
      )
    }
  }

  // define a property
  function setIvar(key, value) {
    var ivarHasBeenSet = key in handlers

    ivars[key] = value

    if (!ivarHasBeenSet) {
      delegateClassDesc.addInstanceVariableWithName_typeEncoding(key, '@')
      var description = MOPropertyDescription.new()
      description.name = key
      description.typeEncoding = '@'
      description.weak = true
      description.ivarName = key
      delegateClassDesc.addProperty(description)
    }
  }

  this.getClass = function() {
    return NSClassFromString(uniqueClassName)
  }

  this.getClassInstance = function(instanceVariables) {
    var instance = NSClassFromString(uniqueClassName).new()
    Object.keys(ivars).forEach(function(key) {
      instance[key] = ivars[key]
    })
    Object.keys(instanceVariables || {}).forEach(function(key) {
      instance[key] = instanceVariables[key]
    })
    return instance
  }
  // alias
  this.new = this.getClassInstance

  // Convenience
  if (typeof definition === 'object') {
    Object.keys(definition).forEach(
      function(key) {
        if (typeof definition[key] === 'function') {
          setHandlerForSelector(key, definition[key])
        } else {
          setIvar(key, definition[key])
        }
      }
    )
  }

  delegateClassDesc.registerClass()
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/browser-api.js":
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/browser-api.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function parseHexColor(color) {
  // Check the string for incorrect formatting.
  if (!color || color[0] !== '#') {
    if (
      color &&
      typeof color.isKindOfClass === 'function' &&
      color.isKindOfClass(NSColor)
    ) {
      return color
    }
    throw new Error(
      'Incorrect color formating. It should be an hex color: #RRGGBBAA'
    )
  }

  // append FF if alpha channel is not specified.
  var source = color.substr(1)
  if (source.length === 3) {
    source += 'F'
  } else if (source.length === 6) {
    source += 'FF'
  }
  // Convert the string from #FFF format to #FFFFFF format.
  var hex
  if (source.length === 4) {
    for (var i = 0; i < 4; i += 1) {
      hex += source[i]
      hex += source[i]
    }
  } else if (source.length === 8) {
    hex = source
  } else {
    return NSColor.whiteColor()
  }

  var r = parseInt(hex.slice(0, 2), 16)
  var g = parseInt(hex.slice(2, 4), 16)
  var b = parseInt(hex.slice(4, 6), 16)
  var a = parseInt(hex.slice(6, 8), 16)

  return NSColor.colorWithSRGBRed_green_blue_alpha(r, g, b, a)
}

module.exports = function(browserWindow, panel, webview) {
  // keep reference to the subviews
  browserWindow._panel = panel
  browserWindow._webview = webview
  browserWindow._destroyed = false

  browserWindow.destroy = function() {
    return panel.close()
  }

  browserWindow.close = function() {
    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      var shouldClose = true
      browserWindow.emit('close', {
        get defaultPrevented() {
          return !shouldClose
        },
        preventDefault: function() {
          shouldClose = false
        },
      })
      if (shouldClose) {
        panel.delegate().utils.parentWindow.endSheet(panel)
      }
      return
    }

    if (!browserWindow.isClosable()) {
      return
    }

    panel.performClose(null)
  }

  function focus(focused) {
    if (!browserWindow.isVisible()) {
      return
    }
    if (focused) {
      NSApplication.sharedApplication().activateIgnoringOtherApps(true)
      panel.makeKeyAndOrderFront(null)
    } else {
      panel.orderBack(null)
      NSApp.mainWindow().makeKeyAndOrderFront(null)
    }
  }

  browserWindow.focus = focus.bind(this, true)
  browserWindow.blur = focus.bind(this, false)

  browserWindow.isFocused = function() {
    return panel.isKeyWindow()
  }

  browserWindow.isDestroyed = function() {
    return browserWindow._destroyed
  }

  browserWindow.show = function() {
    // This method is supposed to put focus on window, however if the app does not
    // have focus then "makeKeyAndOrderFront" will only show the window.
    NSApp.activateIgnoringOtherApps(true)

    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      return panel.delegate().utils.parentWindow.beginSheet_completionHandler(
        panel,
        __mocha__.createBlock_function('v16@?0q8', function() {
          browserWindow.emit('closed')
        })
      )
    }

    return panel.makeKeyAndOrderFront(null)
  }

  browserWindow.showInactive = function() {
    return panel.orderFrontRegardless()
  }

  browserWindow.hide = function() {
    return panel.orderOut(null)
  }

  browserWindow.isVisible = function() {
    return panel.isVisible()
  }

  browserWindow.isModal = function() {
    return false
  }

  browserWindow.maximize = function() {
    if (!browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }
  browserWindow.unmaximize = function() {
    if (browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }

  browserWindow.isMaximized = function() {
    if ((panel.styleMask() & NSResizableWindowMask) !== 0) {
      return panel.isZoomed()
    }
    var rectScreen = NSScreen.mainScreen().visibleFrame()
    var rectWindow = panel.frame()
    return (
      rectScreen.origin.x == rectWindow.origin.x &&
      rectScreen.origin.y == rectWindow.origin.y &&
      rectScreen.size.width == rectWindow.size.width &&
      rectScreen.size.height == rectWindow.size.height
    )
  }

  browserWindow.minimize = function() {
    return panel.miniaturize(null)
  }

  browserWindow.restore = function() {
    return panel.deminiaturize(null)
  }

  browserWindow.isMinimized = function() {
    return panel.isMiniaturized()
  }

  browserWindow.setFullScreen = function(fullscreen) {
    if (fullscreen !== browserWindow.isFullscreen()) {
      panel.toggleFullScreen(null)
    }
  }

  browserWindow.isFullscreen = function() {
    return panel.styleMask() & NSFullScreenWindowMask
  }

  browserWindow.setAspectRatio = function(aspectRatio /* , extraSize */) {
    // Reset the behaviour to default if aspect_ratio is set to 0 or less.
    if (aspectRatio > 0.0) {
      panel.setAspectRatio(NSMakeSize(aspectRatio, 1.0))
    } else {
      panel.setResizeIncrements(NSMakeSize(1.0, 1.0))
    }
  }

  browserWindow.setBounds = function(bounds, animate) {
    if (!bounds) {
      return
    }

    // Do nothing if in fullscreen mode.
    if (browserWindow.isFullscreen()) {
      return
    }

    const newBounds = Object.assign(browserWindow.getBounds(), bounds)

    // TODO: Check size constraints since setFrame does not check it.
    // var size = bounds.size
    // size.SetToMax(GetMinimumSize());
    // gfx::Size max_size = GetMaximumSize();
    // if (!max_size.IsEmpty())
    //   size.SetToMin(max_size);

    var cocoaBounds = NSMakeRect(
      newBounds.x,
      0,
      newBounds.width,
      newBounds.height
    )
    // Flip Y coordinates based on the primary screen
    var screen = NSScreen.screens().firstObject()
    cocoaBounds.origin.y = NSHeight(screen.frame()) - newBounds.y

    panel.setFrame_display_animate(cocoaBounds, true, animate)
  }

  browserWindow.getBounds = function() {
    const cocoaBounds = panel.frame()
    var mainScreenRect = NSScreen.screens()
      .firstObject()
      .frame()
    return {
      x: cocoaBounds.origin.x,
      y: Math.round(NSHeight(mainScreenRect) - cocoaBounds.origin.y),
      width: cocoaBounds.size.width,
      height: cocoaBounds.size.height,
    }
  }

  browserWindow.setContentBounds = function(bounds, animate) {
    // TODO:
    browserWindow.setBounds(bounds, animate)
  }

  browserWindow.getContentBounds = function() {
    // TODO:
    return browserWindow.getBounds()
  }

  browserWindow.setSize = function(width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setBounds({ width: width, height: height }, animate)
  }

  browserWindow.getSize = function() {
    var bounds = browserWindow.getBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setContentSize = function(width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setContentBounds(
      { width: width, height: height },
      animate
    )
  }

  browserWindow.getContentSize = function() {
    var bounds = browserWindow.getContentBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setMinimumSize = function(width, height) {
    const minSize = CGSizeMake(width, height)
    panel.setContentMinSize(minSize)
  }

  browserWindow.getMinimumSize = function() {
    const size = panel.contentMinSize()
    return [size.width, size.height]
  }

  browserWindow.setMaximumSize = function(width, height) {
    const maxSize = CGSizeMake(width, height)
    panel.setContentMaxSize(maxSize)
  }

  browserWindow.getMaximumSize = function() {
    const size = panel.contentMaxSize()
    return [size.width, size.height]
  }

  browserWindow.setResizable = function(resizable) {
    return browserWindow._setStyleMask(resizable, NSResizableWindowMask)
  }

  browserWindow.isResizable = function() {
    return panel.styleMask() & NSResizableWindowMask
  }

  browserWindow.setMovable = function(movable) {
    return panel.setMovable(movable)
  }
  browserWindow.isMovable = function() {
    return panel.isMovable()
  }

  browserWindow.setMinimizable = function(minimizable) {
    return browserWindow._setStyleMask(minimizable, NSMiniaturizableWindowMask)
  }

  browserWindow.isMinimizable = function() {
    return panel.styleMask() & NSMiniaturizableWindowMask
  }

  browserWindow.setMaximizable = function(maximizable) {
    if (panel.standardWindowButton(NSWindowZoomButton)) {
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(maximizable)
    }
  }

  browserWindow.isMaximizable = function() {
    return (
      panel.standardWindowButton(NSWindowZoomButton) &&
      panel.standardWindowButton(NSWindowZoomButton).isEnabled()
    )
  }

  browserWindow.setFullScreenable = function(fullscreenable) {
    browserWindow._setCollectionBehavior(
      fullscreenable,
      NSWindowCollectionBehaviorFullScreenPrimary
    )
    // On EL Capitan this flag is required to hide fullscreen button.
    browserWindow._setCollectionBehavior(
      !fullscreenable,
      NSWindowCollectionBehaviorFullScreenAuxiliary
    )
  }

  browserWindow.isFullScreenable = function() {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorFullScreenPrimary
  }

  browserWindow.setClosable = function(closable) {
    browserWindow._setStyleMask(closable, NSClosableWindowMask)
  }

  browserWindow.isClosable = function() {
    return panel.styleMask() & NSClosableWindowMask
  }

  browserWindow.setAlwaysOnTop = function(top, level, relativeLevel) {
    var windowLevel = NSNormalWindowLevel
    var maxWindowLevel = CGWindowLevelForKey(kCGMaximumWindowLevelKey)
    var minWindowLevel = CGWindowLevelForKey(kCGMinimumWindowLevelKey)

    if (top) {
      if (level === 'normal') {
        windowLevel = NSNormalWindowLevel
      } else if (level === 'torn-off-menu') {
        windowLevel = NSTornOffMenuWindowLevel
      } else if (level === 'modal-panel') {
        windowLevel = NSModalPanelWindowLevel
      } else if (level === 'main-menu') {
        windowLevel = NSMainMenuWindowLevel
      } else if (level === 'status') {
        windowLevel = NSStatusWindowLevel
      } else if (level === 'pop-up-menu') {
        windowLevel = NSPopUpMenuWindowLevel
      } else if (level === 'screen-saver') {
        windowLevel = NSScreenSaverWindowLevel
      } else if (level === 'dock') {
        // Deprecated by macOS, but kept for backwards compatibility
        windowLevel = NSDockWindowLevel
      } else {
        windowLevel = NSFloatingWindowLevel
      }
    }

    var newLevel = windowLevel + (relativeLevel || 0)
    if (newLevel >= minWindowLevel && newLevel <= maxWindowLevel) {
      panel.setLevel(newLevel)
    } else {
      throw new Error(
        'relativeLevel must be between ' +
          minWindowLevel +
          ' and ' +
          maxWindowLevel
      )
    }
  }

  browserWindow.isAlwaysOnTop = function() {
    return panel.level() !== NSNormalWindowLevel
  }

  browserWindow.moveTop = function() {
    return panel.orderFrontRegardless()
  }

  browserWindow.center = function() {
    panel.center()
  }

  browserWindow.setPosition = function(x, y, animate) {
    return browserWindow.setBounds({ x: x, y: y }, animate)
  }

  browserWindow.getPosition = function() {
    var bounds = browserWindow.getBounds()
    return [bounds.x, bounds.y]
  }

  browserWindow.setTitle = function(title) {
    panel.setTitle(title)
  }

  browserWindow.getTitle = function() {
    return String(panel.title())
  }

  var attentionRequestId = 0
  browserWindow.flashFrame = function(flash) {
    if (flash) {
      attentionRequestId = NSApp.requestUserAttention(NSInformationalRequest)
    } else {
      NSApp.cancelUserAttentionRequest(attentionRequestId)
      attentionRequestId = 0
    }
  }

  browserWindow.getNativeWindowHandle = function() {
    return panel
  }

  browserWindow.getNativeWebViewHandle = function() {
    return webview
  }

  browserWindow.loadURL = function(url) {
    // When frameLocation is a file, prefix it with the Sketch Resources path
    if (/^(?!https?|file).*\.html?$/.test(url)) {
      if (typeof __command !== 'undefined' && __command.pluginBundle()) {
        url =
          'file://' +
          __command
            .pluginBundle()
            .urlForResourceNamed(url)
            .path()
      }
    }

    if (/^file:\/\/.*\.html?$/.test(url)) {
      // ensure URLs containing spaces are properly handled
      url = NSString.alloc().initWithString(url)
      url = url.stringByAddingPercentEncodingWithAllowedCharacters(
        NSCharacterSet.URLQueryAllowedCharacterSet()
      )
      webview.loadFileURL_allowingReadAccessToURL(
        NSURL.URLWithString(url),
        NSURL.URLWithString('file:///')
      )
      return
    }

    const properURL = NSURL.URLWithString(url)
    const urlRequest = NSURLRequest.requestWithURL(properURL)

    webview.loadRequest(urlRequest)
  }

  browserWindow.reload = function() {
    webview.reload()
  }

  browserWindow.setHasShadow = function(hasShadow) {
    return panel.setHasShadow(hasShadow)
  }

  browserWindow.hasShadow = function() {
    return panel.hasShadow()
  }

  browserWindow.setOpacity = function(opacity) {
    return panel.setAlphaValue(opacity)
  }

  browserWindow.getOpacity = function() {
    return panel.alphaValue()
  }

  browserWindow.setVisibleOnAllWorkspaces = function(visible) {
    return browserWindow._setCollectionBehavior(
      visible,
      NSWindowCollectionBehaviorCanJoinAllSpaces
    )
  }

  browserWindow.isVisibleOnAllWorkspaces = function() {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorCanJoinAllSpaces
  }

  browserWindow.setIgnoreMouseEvents = function(ignore) {
    return panel.setIgnoresMouseEvents(ignore)
  }

  browserWindow.setContentProtection = function(enable) {
    panel.setSharingType(enable ? NSWindowSharingNone : NSWindowSharingReadOnly)
  }

  browserWindow.setAutoHideCursor = function(autoHide) {
    panel.setDisableAutoHideCursor(autoHide)
  }

  browserWindow.setVibrancy = function(type) {
    var effectView = browserWindow._vibrantView

    if (!type) {
      if (effectView == null) {
        return
      }

      effectView.removeFromSuperview()
      panel.setVibrantView(null)
      return
    }

    if (effectView == null) {
      var contentView = panel.contentView()
      effectView = NSVisualEffectView.alloc().initWithFrame(
        contentView.bounds()
      )
      browserWindow._vibrantView = effectView

      effectView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
      effectView.setBlendingMode(NSVisualEffectBlendingModeBehindWindow)
      effectView.setState(NSVisualEffectStateActive)
      effectView.setFrame(contentView.bounds())
      contentView.addSubview_positioned_relativeTo(
        effectView,
        NSWindowBelow,
        null
      )
    }

    var vibrancyType = NSVisualEffectMaterialLight

    if (type === 'appearance-based') {
      vibrancyType = NSVisualEffectMaterialAppearanceBased
    } else if (type === 'light') {
      vibrancyType = NSVisualEffectMaterialLight
    } else if (type === 'dark') {
      vibrancyType = NSVisualEffectMaterialDark
    } else if (type === 'titlebar') {
      vibrancyType = NSVisualEffectMaterialTitlebar
    } else if (type === 'selection') {
      vibrancyType = NSVisualEffectMaterialSelection
    } else if (type === 'menu') {
      vibrancyType = NSVisualEffectMaterialMenu
    } else if (type === 'popover') {
      vibrancyType = NSVisualEffectMaterialPopover
    } else if (type === 'sidebar') {
      vibrancyType = NSVisualEffectMaterialSidebar
    } else if (type === 'medium-light') {
      vibrancyType = NSVisualEffectMaterialMediumLight
    } else if (type === 'ultra-dark') {
      vibrancyType = NSVisualEffectMaterialUltraDark
    }

    effectView.setMaterial(vibrancyType)
  }

  browserWindow._setBackgroundColor = function(colorName) {
    var color = parseHexColor(colorName)
    webview.setValue_forKey(false, 'drawsBackground')
    panel.backgroundColor = color
  }

  browserWindow._invalidate = function() {
    panel.flushWindow()
    panel.contentView().setNeedsDisplay(true)
  }

  browserWindow._setStyleMask = function(on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setStyleMask(panel.styleMask() | flag)
    } else {
      panel.setStyleMask(panel.styleMask() & ~flag)
    }
    // Change style mask will make the zoom button revert to default, probably
    // a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._setCollectionBehavior = function(on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setCollectionBehavior(panel.collectionBehavior() | flag)
    } else {
      panel.setCollectionBehavior(panel.collectionBehavior() & ~flag)
    }
    // Change collectionBehavior will make the zoom button revert to default,
    // probably a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._showWindowButton = function(button) {
    var view = panel.standardWindowButton(button)
    view.superview().addSubview_positioned_relative(view, NSWindowAbove, null)
  }
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/constants.js":
/*!**************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/constants.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  JS_BRIDGE: '__skpm_sketchBridge',
  JS_BRIDGE_RESULT_SUCCESS: '__skpm_sketchBridge_success',
  JS_BRIDGE_RESULT_ERROR: '__skpm_sketchBridge_error',
  START_MOVING_WINDOW: '__skpm_startMovingWindow',
  EXECUTE_JAVASCRIPT: '__skpm_executeJS',
  EXECUTE_JAVASCRIPT_SUCCESS: '__skpm_executeJS_success_',
  EXECUTE_JAVASCRIPT_ERROR: '__skpm_executeJS_error_',
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js":
/*!*************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/dispatch-first-click.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var tagsToFocus =
  '["text", "textarea", "date", "datetime-local", "email", "number", "month", "password", "search", "tel", "time", "url", "week" ]'

module.exports = function(webView, event) {
  var point = webView.convertPoint_fromView(event.locationInWindow(), null)
  return (
    'var el = document.elementFromPoint(' + // get the DOM element that match the event
    point.x +
    ', ' +
    point.y +
    '); ' +
    'if (el && el.tagName === "SELECT") {' + // select needs special handling
    '  var event = document.createEvent("MouseEvents");' +
    '  event.initMouseEvent("mousedown", true, true, window);' +
    '  el.dispatchEvent(event);' +
    '} else if (el && ' + // some tags need to be focused instead of clicked
    tagsToFocus +
    '.indexOf(el.type) >= 0 && ' +
    'el.focus' +
    ') {' +
    'el.focus();' + // so focus them
    '} else if (el) {' +
    'el.dispatchEvent(new Event("click", {bubbles: true}))' + // click the others
    '}'
  )
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/execute-javascript.js":
/*!***********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/execute-javascript.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function(webview, browserWindow) {
  function executeJavaScript(script, userGesture, callback) {
    if (typeof userGesture === 'function') {
      callback = userGesture
      userGesture = false
    }
    var fiber = coscript.createFiber()

    // if the webview is not ready yet, defer the execution until it is
    if (
      webview.navigationDelegate().state &&
      webview.navigationDelegate().state.wasReady == 0
    ) {
      return new Promise(function(resolve, reject) {
        browserWindow.once('ready-to-show', function() {
          executeJavaScript(script, userGesture, callback)
            .then(resolve)
            .catch(reject)
          fiber.cleanup()
        })
      })
    }

    return new Promise(function(resolve, reject) {
      var requestId = Math.random()

      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS + requestId,
        function(res) {
          try {
            if (callback) {
              callback(null, res)
            }
            resolve(res)
          } catch (err) {
            reject(err)
          }
          fiber.cleanup()
        }
      )
      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_ERROR + requestId,
        function(err) {
          try {
            if (callback) {
              callback(err)
              resolve()
            } else {
              reject(err)
            }
          } catch (err2) {
            reject(err2)
          }
          fiber.cleanup()
        }
      )

      webview.evaluateJavaScript_completionHandler(
        module.exports.wrapScript(script, requestId),
        null
      )
    })
  }

  return executeJavaScript
}

module.exports.wrapScript = function(script, requestId) {
  return (
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    '(' +
    requestId +
    ', ' +
    JSON.stringify(script) +
    ')'
  )
}

module.exports.injectScript = function(webView) {
  var source =
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    ' = function(id, script) {' +
    '  try {' +
    '    var res = eval(script);' +
    '    if (res && typeof res.then === "function" && typeof res.catch === "function") {' +
    '      res.then(function (res2) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res2);' +
    '      })' +
    '      .catch(function (err) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '      })' +
    '    } else {' +
    '      window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res);' +
    '    }' +
    '  } catch (err) {' +
    '    window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '  }' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView
    .configuration()
    .userContentController()
    .addUserScript(script)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/fitSubview.js":
/*!***************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/fitSubview.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function addEdgeConstraint(edge, subview, view, constant) {
  view.addConstraint(
    NSLayoutConstraint.constraintWithItem_attribute_relatedBy_toItem_attribute_multiplier_constant(
      subview,
      edge,
      NSLayoutRelationEqual,
      view,
      edge,
      1,
      constant
    )
  )
}
module.exports = function fitSubviewToView(subview, view, constants) {
  constants = constants || []
  subview.setTranslatesAutoresizingMaskIntoConstraints(false)

  addEdgeConstraint(NSLayoutAttributeLeft, subview, view, constants[0] || 0)
  addEdgeConstraint(NSLayoutAttributeTop, subview, view, constants[1] || 0)
  addEdgeConstraint(NSLayoutAttributeRight, subview, view, constants[2] || 0)
  addEdgeConstraint(NSLayoutAttributeBottom, subview, view, constants[3] || 0)
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* let's try to match the API from Electron's Browser window
(https://github.com/electron/electron/blob/master/docs/api/browser-window.md) */
var EventEmitter = __webpack_require__(/*! events */ "events")
var buildBrowserAPI = __webpack_require__(/*! ./browser-api */ "./node_modules/sketch-module-web-view/lib/browser-api.js")
var buildWebAPI = __webpack_require__(/*! ./webview-api */ "./node_modules/sketch-module-web-view/lib/webview-api.js")
var fitSubviewToView = __webpack_require__(/*! ./fitSubview */ "./node_modules/sketch-module-web-view/lib/fitSubview.js")
var dispatchFirstClick = __webpack_require__(/*! ./dispatch-first-click */ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js")
var injectClientMessaging = __webpack_require__(/*! ./inject-client-messaging */ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js")
var movableArea = __webpack_require__(/*! ./movable-area */ "./node_modules/sketch-module-web-view/lib/movable-area.js")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")
var setDelegates = __webpack_require__(/*! ./set-delegates */ "./node_modules/sketch-module-web-view/lib/set-delegates.js")

function BrowserWindow(options) {
  options = options || {}

  var identifier = options.identifier || NSUUID.UUID().UUIDString()
  var threadDictionary = NSThread.mainThread().threadDictionary()

  var existingBrowserWindow = BrowserWindow.fromId(identifier)

  // if we already have a window opened, reuse it
  if (existingBrowserWindow) {
    return existingBrowserWindow
  }

  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (options.modal && !options.parent) {
    throw new Error('A modal needs to have a parent.')
  }

  // Long-running script
  var fiber = coscript.createFiber()

  // Window size
  var width = options.width || 800
  var height = options.height || 600
  var mainScreenRect = NSScreen.screens()
    .firstObject()
    .frame()
  var cocoaBounds = NSMakeRect(
    typeof options.x !== 'undefined'
      ? options.x
      : Math.round((NSWidth(mainScreenRect) - width) / 2),
    typeof options.y !== 'undefined'
      ? NSHeight(mainScreenRect) - options.y
      : Math.round((NSHeight(mainScreenRect) - height) / 2),
    width,
    height
  )

  if (options.titleBarStyle && options.titleBarStyle !== 'default') {
    options.frame = false
  }

  var useStandardWindow = options.windowType !== 'textured'
  var styleMask = NSTitledWindowMask

  // this is commented out because the toolbar doesn't appear otherwise :thinking-face:
  // if (!useStandardWindow || options.frame === false) {
  //   styleMask = NSFullSizeContentViewWindowMask
  // }
  if (options.minimizable !== false) {
    styleMask |= NSMiniaturizableWindowMask
  }
  if (options.closable !== false) {
    styleMask |= NSClosableWindowMask
  }
  if (options.resizable !== false) {
    styleMask |= NSResizableWindowMask
  }
  if (!useStandardWindow || options.transparent || options.frame === false) {
    styleMask |= NSTexturedBackgroundWindowMask
  }

  var panel = NSPanel.alloc().initWithContentRect_styleMask_backing_defer(
    cocoaBounds,
    styleMask,
    NSBackingStoreBuffered,
    true
  )

  var wkwebviewConfig = WKWebViewConfiguration.alloc().init()
  var webView = WKWebView.alloc().initWithFrame_configuration(
    CGRectMake(0, 0, options.width || 800, options.height || 600),
    wkwebviewConfig
  )
  injectClientMessaging(webView)
  webView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)
  setDelegates(browserWindow, panel, webView, options)

  if (options.windowType === 'desktop') {
    panel.setLevel(kCGDesktopWindowLevel - 1)
    // panel.setCanBecomeKeyWindow(false)
    panel.setCollectionBehavior(
      NSWindowCollectionBehaviorCanJoinAllSpaces |
        NSWindowCollectionBehaviorStationary |
        NSWindowCollectionBehaviorIgnoresCycle
    )
  }

  if (
    typeof options.minWidth !== 'undefined' ||
    typeof options.minHeight !== 'undefined'
  ) {
    browserWindow.setMinimumSize(options.minWidth || 0, options.minHeight || 0)
  }

  if (
    typeof options.maxWidth !== 'undefined' ||
    typeof options.maxHeight !== 'undefined'
  ) {
    browserWindow.setMaximumSize(
      options.maxWidth || 10000,
      options.maxHeight || 10000
    )
  }

  // if (options.focusable === false) {
  //   panel.setCanBecomeKeyWindow(false)
  // }

  if (options.transparent || options.frame === false) {
    panel.titlebarAppearsTransparent = true
    panel.titleVisibility = NSWindowTitleHidden
    panel.setOpaque(0)
    panel.isMovableByWindowBackground = true
    var toolbar2 = NSToolbar.alloc().initWithIdentifier(
      'titlebarStylingToolbar'
    )
    toolbar2.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar2)
  }

  if (options.titleBarStyle === 'hiddenInset') {
    var toolbar = NSToolbar.alloc().initWithIdentifier('titlebarStylingToolbar')
    toolbar.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar)
  }

  if (options.frame === false || !options.useContentSize) {
    browserWindow.setSize(width, height)
  }

  if (options.center) {
    browserWindow.center()
  }

  if (options.alwaysOnTop) {
    browserWindow.setAlwaysOnTop(true)
  }

  if (options.fullscreen) {
    browserWindow.setFullScreen(true)
  }
  browserWindow.setFullScreenable(!!options.fullscreenable)

  let title = options.title
  if (options.frame === false) {
    title = undefined
  } else if (
    typeof title === 'undefined' &&
    typeof __command !== 'undefined' &&
    __command.pluginBundle()
  ) {
    title = __command.pluginBundle().name()
  }

  if (title) {
    browserWindow.setTitle(title)
  }

  var backgroundColor = options.backgroundColor
  if (options.transparent) {
    backgroundColor = NSColor.clearColor()
  }
  if (!backgroundColor && options.frame === false && options.vibrancy) {
    backgroundColor = NSColor.clearColor()
  }

  browserWindow._setBackgroundColor(
    backgroundColor || NSColor.windowBackgroundColor()
  )

  if (options.hasShadow === false) {
    browserWindow.setHasShadow(false)
  }

  if (typeof options.opacity !== 'undefined') {
    browserWindow.setOpacity(options.opacity)
  }

  options.webPreferences = options.webPreferences || {}

  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.devTools !== false,
      'developerExtrasEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.javascript !== false,
      'javaScriptEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(!!options.webPreferences.plugins, 'plugInsEnabled')
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.minimumFontSize || 0,
      'minimumFontSize'
    )

  if (options.webPreferences.zoomFactor) {
    webView.setMagnification(options.webPreferences.zoomFactor)
  }

  var contentView = panel.contentView()

  if (options.frame !== false) {
    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)
  } else {
    // In OSX 10.10, adding subviews to the root view for the NSView hierarchy
    // produces warnings. To eliminate the warnings, we resize the contentView
    // to fill the window, and add subviews to that.
    // http://crbug.com/380412
    contentView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
    fitSubviewToView(contentView, contentView.superview())

    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)

    // The fullscreen button should always be hidden for frameless window.
    if (panel.standardWindowButton(NSWindowFullScreenButton)) {
      panel.standardWindowButton(NSWindowFullScreenButton).setHidden(true)
    }

    if (!options.titleBarStyle || options.titleBarStyle === 'default') {
      // Hide the window buttons.
      panel.standardWindowButton(NSWindowZoomButton).setHidden(true)
      panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true)
      panel.standardWindowButton(NSWindowCloseButton).setHidden(true)

      // Some third-party macOS utilities check the zoom button's enabled state to
      // determine whether to show custom UI on hover, so we disable it here to
      // prevent them from doing so in a frameless app window.
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(false)
    }
  }

  if (options.vibrancy) {
    browserWindow.setVibrancy(options.vibrancy)
  }

  // Set maximizable state last to ensure zoom button does not get reset
  // by calls to other APIs.
  browserWindow.setMaximizable(options.maximizable !== false)

  panel.setHidesOnDeactivate(options.hidesOnDeactivate !== false)

  if (options.remembersWindowFrame) {
    panel.setFrameAutosaveName(identifier)
    panel.setFrameUsingName_force(panel.frameAutosaveName(), false)
  }

  if (options.acceptsFirstMouse) {
    browserWindow.on('focus', function(event) {
      if (event.type() === NSEventTypeLeftMouseDown) {
        browserWindow.webContents
          .executeJavaScript(dispatchFirstClick(webView, event))
          .catch(() => {})
      }
    })
  }

  executeJavaScript.injectScript(webView)
  movableArea.injectScript(webView)
  movableArea.setupHandler(browserWindow)

  if (options.show !== false) {
    browserWindow.show()
  }

  browserWindow.on('closed', function() {
    browserWindow._destroyed = true
    threadDictionary.removeObjectForKey(identifier)
    var observer = threadDictionary[identifier + '.themeObserver']
    if (observer) {
      NSApplication.sharedApplication().removeObserver_forKeyPath(
        observer,
        'effectiveAppearance'
      )
      threadDictionary.removeObjectForKey(identifier + '.themeObserver')
    }
    fiber.cleanup()
  })

  threadDictionary[identifier] = panel

  fiber.onCleanup(function() {
    if (!browserWindow._destroyed) {
      browserWindow.destroy()
    }
  })

  return browserWindow
}

BrowserWindow.fromId = function(identifier) {
  var threadDictionary = NSThread.mainThread().threadDictionary()

  if (threadDictionary[identifier]) {
    return BrowserWindow.fromPanel(threadDictionary[identifier], identifier)
  }

  return undefined
}

BrowserWindow.fromPanel = function(panel, identifier) {
  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (!panel || !panel.contentView) {
    throw new Error('needs to pass an NSPanel')
  }

  var webView = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webView &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webView = subviews[i]
    }
  }

  if (!webView) {
    throw new Error('The panel needs to have a webview')
  }

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)

  return browserWindow
}

module.exports = BrowserWindow


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js":
/*!****************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/inject-client-messaging.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function(webView) {
  var source =
    'window.originalPostMessage = window.postMessage;' +
    'window.postMessage = function(actionName) {' +
    '  if (!actionName) {' +
    "    throw new Error('missing action name')" +
    '  }' +
    '  var id = String(Math.random()).replace(".", "");' +
    '    var args = [].slice.call(arguments);' +
    '    args.unshift(id);' +
    '  return new Promise(function (resolve, reject) {' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
    '" + id] = resolve;' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_ERROR +
    '" + id] = reject;' +
    '    window.webkit.messageHandlers.' +
    CONSTANTS.JS_BRIDGE +
    '.postMessage(JSON.stringify(args));' +
    '  });' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView
    .configuration()
    .userContentController()
    .addUserScript(script)
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/movable-area.js":
/*!*****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/movable-area.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports.injectScript = function(webView) {
  var source =
    '(function () {' +
    "document.addEventListener('mousedown', onMouseDown);" +
    '' +
    'function shouldDrag(target) {' +
    '  if (!target || (target.dataset || {}).appRegion === "no-drag") { return false }' +
    '  if ((target.dataset || {}).appRegion === "drag") { return true }' +
    '  return shouldDrag(target.parentElement)' +
    '};' +
    '' +
    'function onMouseDown(e) {' +
    '  if (e.button !== 0 || !shouldDrag(e.target)) { return }' +
    '  window.postMessage("' +
    CONSTANTS.START_MOVING_WINDOW +
    '");' +
    '};' +
    '})()'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView
    .configuration()
    .userContentController()
    .addUserScript(script)
}

module.exports.setupHandler = function(browserWindow) {
  var initialMouseLocation = null
  var initialWindowPosition = null
  var interval = null

  function moveWindow() {
    // if the user released the button, stop moving the window
    if (!initialWindowPosition || NSEvent.pressedMouseButtons() !== 1) {
      clearInterval(interval)
      initialMouseLocation = null
      initialWindowPosition = null
      return
    }

    var mouse = NSEvent.mouseLocation()
    browserWindow.setPosition(
      initialWindowPosition.x + (mouse.x - initialMouseLocation.x),
      initialWindowPosition.y + (initialMouseLocation.y - mouse.y), // y is inverted
      false
    )
  }

  browserWindow.webContents.on(CONSTANTS.START_MOVING_WINDOW, function() {
    initialMouseLocation = NSEvent.mouseLocation()
    var position = browserWindow.getPosition()
    initialWindowPosition = {
      x: position[0],
      y: position[1],
    }

    interval = setInterval(moveWindow, 1000 / 60) // 60 fps
  })
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js":
/*!**********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/parseWebArguments.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function(webArguments) {
  var args = null
  try {
    args = JSON.parse(webArguments)
  } catch (e) {
    // malformed arguments
  }

  if (
    !args ||
    !args.constructor ||
    args.constructor !== Array ||
    args.length == 0
  ) {
    return null
  }

  return args
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/set-delegates.js":
/*!******************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/set-delegates.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {var ObjCClass = __webpack_require__(/*! mocha-js-delegate */ "./node_modules/mocha-js-delegate/index.js")
var parseWebArguments = __webpack_require__(/*! ./parseWebArguments */ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js")
var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

// We create one ObjC class for ourselves here
var WindowDelegateClass
var NavigationDelegateClass
var WebScriptHandlerClass
var ThemeObserverClass

// TODO: events
// - 'page-favicon-updated'
// - 'new-window'
// - 'did-navigate-in-page'
// - 'will-prevent-unload'
// - 'crashed'
// - 'unresponsive'
// - 'responsive'
// - 'destroyed'
// - 'before-input-event'
// - 'certificate-error'
// - 'found-in-page'
// - 'media-started-playing'
// - 'media-paused'
// - 'did-change-theme-color'
// - 'update-target-url'
// - 'cursor-changed'
// - 'context-menu'
// - 'select-bluetooth-device'
// - 'paint'
// - 'console-message'

module.exports = function(browserWindow, panel, webview, options) {
  if (!ThemeObserverClass) {
    ThemeObserverClass = new ObjCClass({
      utils: null,

      'observeValueForKeyPath:ofObject:change:context:': function() {
        this.utils.executeJavaScript(
          "document.body.classList.remove('__skpm-" +
            (typeof MSTheme !== 'undefined' && MSTheme.sharedTheme().isDark()
              ? 'light'
              : 'dark') +
            "'); document.body.classList.add('__skpm-" +
            (typeof MSTheme !== 'undefined' && MSTheme.sharedTheme().isDark()
              ? 'dark'
              : 'light') +
            "')"
        )
      },
    })
  }

  if (!WindowDelegateClass) {
    WindowDelegateClass = new ObjCClass({
      utils: null,
      panel: null,

      'windowDidResize:': function() {
        this.utils.emit('resize')
      },

      'windowDidMiniaturize:': function() {
        this.utils.emit('minimize')
      },

      'windowDidDeminiaturize:': function() {
        this.utils.emit('restore')
      },

      'windowDidEnterFullScreen:': function() {
        this.utils.emit('enter-full-screen')
      },

      'windowDidExitFullScreen:': function() {
        this.utils.emit('leave-full-screen')
      },

      'windowDidMove:': function() {
        this.utils.emit('move')
        this.utils.emit('moved')
      },

      'windowShouldClose:': function() {
        var shouldClose = 1
        this.utils.emit('close', {
          get defaultPrevented() {
            return !shouldClose
          },
          preventDefault: function() {
            shouldClose = 0
          },
        })
        return shouldClose
      },

      'windowWillClose:': function() {
        this.utils.emit('closed')
      },

      'windowDidBecomeKey:': function() {
        this.utils.emit('focus', this.panel.currentEvent())
      },

      'windowDidResignKey:': function() {
        this.utils.emit('blur')
      },
    })
  }

  if (!NavigationDelegateClass) {
    NavigationDelegateClass = new ObjCClass({
      state: {
        wasReady: 0,
      },
      utils: null,

      // // Called when the web view begins to receive web content.
      'webView:didCommitNavigation:': function(webView) {
        this.utils.emit('will-navigate', {}, String(String(webView.URL())))
      },

      // // Called when web content begins to load in a web view.
      'webView:didStartProvisionalNavigation:': function() {
        this.utils.emit('did-start-navigation')
        this.utils.emit('did-start-loading')
      },

      // Called when a web view receives a server redirect.
      'webView:didReceiveServerRedirectForProvisionalNavigation:': function() {
        this.utils.emit('did-get-redirect-request')
      },

      // // Called when the web view needs to respond to an authentication challenge.
      // 'webView:didReceiveAuthenticationChallenge:completionHandler:': function(
      //   webView,
      //   challenge,
      //   completionHandler
      // ) {
      //   function callback(username, password) {
      //     completionHandler(
      //       0,
      //       NSURLCredential.credentialWithUser_password_persistence(
      //         username,
      //         password,
      //         1
      //       )
      //     )
      //   }
      //   var protectionSpace = challenge.protectionSpace()
      //   this.utils.emit(
      //     'login',
      //     {},
      //     {
      //       method: String(protectionSpace.authenticationMethod()),
      //       url: 'not implemented', // TODO:
      //       referrer: 'not implemented', // TODO:
      //     },
      //     {
      //       isProxy: !!protectionSpace.isProxy(),
      //       scheme: String(protectionSpace.protocol()),
      //       host: String(protectionSpace.host()),
      //       port: Number(protectionSpace.port()),
      //       realm: String(protectionSpace.realm()),
      //     },
      //     callback
      //   )
      // },

      // Called when an error occurs during navigation.
      // 'webView:didFailNavigation:withError:': function(
      //   webView,
      //   navigation,
      //   error
      // ) {},

      // Called when an error occurs while the web view is loading content.
      'webView:didFailProvisionalNavigation:withError:': function(
        webView,
        navigation,
        error
      ) {
        this.utils.emit('did-fail-load', error)
      },

      // Called when the navigation is complete.
      'webView:didFinishNavigation:': function() {
        if (this.state.wasReady == 0) {
          this.state.wasReady = 1
          this.utils.emitBrowserEvent('ready-to-show')
        }
        this.utils.emit('did-navigate')
        this.utils.emit('did-frame-navigate')
        this.utils.emit('did-stop-loading')
        this.utils.emit('did-finish-load')
        this.utils.emit('did-frame-finish-load')
      },

      // Called when the web view’s web content process is terminated.
      'webViewWebContentProcessDidTerminate:': function() {
        this.utils.emit('dom-ready')
      },

      // Decides whether to allow or cancel a navigation.
      // webView:decidePolicyForNavigationAction:decisionHandler:

      // Decides whether to allow or cancel a navigation after its response is known.
      // webView:decidePolicyForNavigationResponse:decisionHandler:
    })
  }

  if (!WebScriptHandlerClass) {
    WebScriptHandlerClass = new ObjCClass({
      utils: null,
      'userContentController:didReceiveScriptMessage:': function(_, message) {
        var args = this.utils.parseWebArguments(String(message.body()))
        if (!args) {
          return
        }
        if (!args[0] || typeof args[0] !== 'string') {
          return
        }
        args[0] = String(args[0])

        this.utils.emit.apply(this, args)
      },
    })
  }

  var themeObserver = ThemeObserverClass.new({
    utils: {
      executeJavaScript(script) {
        webview.evaluateJavaScript_completionHandler(script, null)
      },
    },
  })

  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    "document.addEventListener('DOMContentLoaded', function() { document.body.classList.add('__skpm-" +
      (typeof MSTheme !== 'undefined' && MSTheme.sharedTheme().isDark()
        ? 'dark'
        : 'light') +
      "') }, false)",
    0,
    true
  )
  webview
    .configuration()
    .userContentController()
    .addUserScript(script)

  NSApplication.sharedApplication().addObserver_forKeyPath_options_context(
    themeObserver,
    'effectiveAppearance',
    NSKeyValueChangeNewKey,
    null
  )

  var threadDictionary = NSThread.mainThread().threadDictionary()
  threadDictionary[browserWindow.id + '.themeObserver'] = themeObserver

  var navigationDelegate = NavigationDelegateClass.new({
    utils: {
      setTitle: browserWindow.setTitle.bind(browserWindow),
      emitBrowserEvent() {
        try {
          browserWindow.emit.apply(browserWindow, arguments)
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
      emit() {
        try {
          browserWindow.webContents.emit.apply(
            browserWindow.webContents,
            arguments
          )
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
    },
    state: {
      wasReady: 0,
    },
  })

  webview.setNavigationDelegate(navigationDelegate)

  var webScriptHandler = WebScriptHandlerClass.new({
    utils: {
      emit(id, type) {
        if (!type) {
          webview.evaluateJavaScript_completionHandler(
            CONSTANTS.JS_BRIDGE_RESULT_SUCCESS + id + '()',
            null
          )
          return
        }

        var args = []
        for (var i = 2; i < arguments.length; i += 1) args.push(arguments[i])

        var listeners = browserWindow.webContents.listeners(type)

        Promise.all(
          listeners.map(function(l) {
            return Promise.resolve().then(function() {
              return l.apply(l, args)
            })
          })
        )
          .then(function(res) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
                id +
                '(' +
                JSON.stringify(res) +
                ')',
              null
            )
          })
          .catch(function(err) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_ERROR +
                id +
                '(' +
                JSON.stringify(err) +
                ')',
              null
            )
          })
      },
      parseWebArguments: parseWebArguments,
    },
  })

  webview
    .configuration()
    .userContentController()
    .addScriptMessageHandler_name(webScriptHandler, CONSTANTS.JS_BRIDGE)

  var utils = {
    emit() {
      try {
        browserWindow.emit.apply(browserWindow, arguments)
      } catch (err) {
        if (
          typeof process !== 'undefined' &&
          process.listenerCount &&
          process.listenerCount('uncaughtException')
        ) {
          process.emit('uncaughtException', err, 'uncaughtException')
        } else {
          console.error(err)
          throw err
        }
      }
    },
  }
  if (options.modal) {
    // find the window of the document
    var msdocument
    if (options.parent.type === 'Document') {
      msdocument = options.parent.sketchObject
    } else {
      msdocument = options.parent
    }
    if (msdocument && String(msdocument.class()) === 'MSDocumentData') {
      // we only have an MSDocumentData instead of a MSDocument
      // let's try to get back to the MSDocument
      msdocument = msdocument.delegate()
    }
    utils.parentWindow = msdocument.windowForSheet()
  }

  var windowDelegate = WindowDelegateClass.new({
    utils: utils,
    panel: panel,
  })

  panel.setDelegate(windowDelegate)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/webview-api.js":
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/webview-api.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var EventEmitter = __webpack_require__(/*! events */ "events")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")

// let's try to match https://github.com/electron/electron/blob/master/docs/api/web-contents.md
module.exports = function buildAPI(browserWindow, panel, webview) {
  var webContents = new EventEmitter()

  webContents.loadURL = browserWindow.loadURL

  webContents.loadFile = function(/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.downloadURL = function(/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.getURL = function() {
    return String(webview.url())
  }

  webContents.getTitle = function() {
    return String(webview.title())
  }

  webContents.isDestroyed = function() {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.focus = browserWindow.focus
  webContents.isFocused = browserWindow.isFocused

  webContents.isLoading = function() {
    return !!webview.loading()
  }

  webContents.isLoadingMainFrame = function() {
    // TODO:
    return !!webview.loading()
  }

  webContents.isWaitingForResponse = function() {
    return !webview.loading()
  }

  webContents.stop = function() {
    webview.stopLoading()
  }
  webContents.reload = function() {
    webview.reload()
  }
  webContents.reloadIgnoringCache = function() {
    webview.reloadFromOrigin()
  }
  webContents.canGoBack = function() {
    return !!webview.canGoBack()
  }
  webContents.canGoForward = function() {
    return !!webview.canGoForward()
  }
  webContents.canGoToOffset = function(offset) {
    return !!webview.backForwardList().itemAtIndex(offset)
  }
  webContents.clearHistory = function() {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.goBack = function() {
    webview.goBack()
  }
  webContents.goForward = function() {
    webview.goForward()
  }
  webContents.goToIndex = function(index) {
    var backForwardList = webview.backForwardList()
    var backList = backForwardList.backList()
    var backListLength = backList.count()
    if (backListLength > index) {
      webview.loadRequest(NSURLRequest.requestWithURL(backList[index]))
      return
    }
    var forwardList = backForwardList.forwardList()
    if (forwardList.count() > index - backListLength) {
      webview.loadRequest(
        NSURLRequest.requestWithURL(forwardList[index - backListLength])
      )
      return
    }
    throw new Error('Cannot go to index ' + index)
  }
  webContents.goToOffset = function(offset) {
    if (!webContents.canGoToOffset(offset)) {
      throw new Error('Cannot go to offset ' + offset)
    }
    webview.loadRequest(
      NSURLRequest.requestWithURL(webview.backForwardList().itemAtIndex(offset))
    )
  }
  webContents.isCrashed = function() {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setUserAgent = function(/* userAgent */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.getUserAgent = function() {
    const userAgent = webview.customUserAgent()
    return userAgent ? String(userAgent) : undefined
  }
  webContents.insertCSS = function(css) {
    var source =
      "var style = document.createElement('style'); style.innerHTML = " +
      css.replace(/"/, '\\"') +
      '; document.head.appendChild(style);'
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview
      .configuration()
      .userContentController()
      .addUserScript(script)
  }
  webContents.insertJS = function(source) {
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview
      .configuration()
      .userContentController()
      .addUserScript(script)
  }
  webContents.executeJavaScript = executeJavaScript(webview, browserWindow)
  webContents.setIgnoreMenuShortcuts = function() {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setAudioMuted = function(/* muted */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.isAudioMuted = function() {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setZoomFactor = function(factor) {
    webview.setMagnification_centeredAtPoint(factor, CGPointMake(0, 0))
  }
  webContents.getZoomFactor = function(callback) {
    callback(Number(webview.magnification()))
  }
  webContents.setZoomLevel = function(level) {
    // eslint-disable-next-line no-restricted-properties
    webContents.setZoomFactor(Math.pow(1.2, level))
  }
  webContents.getZoomLevel = function(callback) {
    // eslint-disable-next-line no-restricted-properties
    callback(Math.log(Number(webview.magnification())) / Math.log(1.2))
  }
  webContents.setVisualZoomLevelLimits = function(/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setLayoutZoomLevelLimits = function(/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  // TODO:
  // webContents.undo = function() {
  //   webview.undoManager().undo()
  // }
  // webContents.redo = function() {
  //   webview.undoManager().redo()
  // }
  // webContents.cut = webview.cut
  // webContents.copy = webview.copy
  // webContents.paste = webview.paste
  // webContents.pasteAndMatchStyle = webview.pasteAsRichText
  // webContents.delete = webview.delete
  // webContents.replace = webview.replaceSelectionWithText

  webContents.send = function() {
    const script =
      'window.postMessage({' +
      'isSketchMessage: true,' +
      "origin: '" +
      String(__command.identifier()) +
      "'," +
      'args: ' +
      JSON.stringify([].slice.call(arguments)) +
      '}, "*")'
    webview.evaluateJavaScript_completionHandler(script, null)
  }

  webContents.getNativeWebview = function() {
    return webview
  }

  browserWindow.webContents = webContents
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/remote.js":
/*!*******************************************************!*\
  !*** ./node_modules/sketch-module-web-view/remote.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* globals NSThread */
var threadDictionary = NSThread.mainThread().threadDictionary()

module.exports.getWebview = function(identifier) {
  return __webpack_require__(/*! ./lib */ "./node_modules/sketch-module-web-view/lib/index.js").fromId(identifier) // eslint-disable-line
}

module.exports.isWebviewPresent = function isWebviewPresent(identifier) {
  return !!threadDictionary[identifier]
}

module.exports.sendToWebview = function sendToWebview(identifier, evalString) {
  if (!module.exports.isWebviewPresent(identifier)) {
    return
  }

  var panel = threadDictionary[identifier]
  var webview = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webview &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webview = subviews[i]
    }
  }

  if (!webview || !webview.evaluateJavaScript_completionHandler) {
    throw new Error('Webview ' + identifier + ' not found')
  }

  webview.evaluateJavaScript_completionHandler(evalString, null)
}


/***/ }),

/***/ "./node_modules/sketch-polyfill-fetch/lib/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var error;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          error
        );
        if (error != null) {
          return reject(error);
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, error) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          if (error) {
            finished = true;
            return reject(error);
          }
          return resolve(response(res, data));
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./resources/webview.html":
/*!********************************!*\
  !*** ./resources/webview.html ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "file://" + String(context.scriptPath).split(".sketchplugin/Contents/Sketch")[0] + ".sketchplugin/Contents/Resources/_webpack_resources/b2b055a328d5abae6968929d74a7ac61.html";

/***/ }),

/***/ "./src/plugin.js":
/*!***********************!*\
  !*** ./src/plugin.js ***!
  \***********************/
/*! exports provided: default, onShutdown, fetchAEUX, detachSymbols, flattenCompounds, rasterizeGroups */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onShutdown", function() { return onShutdown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchAEUX", function() { return fetchAEUX; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detachSymbols", function() { return detachSymbols; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "flattenCompounds", function() { return flattenCompounds; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rasterizeGroups", function() { return rasterizeGroups; });
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch-module-web-view */ "./node_modules/sketch-module-web-view/lib/index.js");
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch-module-web-view/remote */ "./node_modules/sketch-module-web-view/remote.js");
/* harmony import */ var sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sketch/ui */ "sketch/ui");
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_2__);
/*jshint esversion: 6, asi: true */



var devName = 'sumUX';
var toolName = 'AEUX';
var docUrl = 'https://aeux.io/';
var versionNumber = 0.78;
var document,
    selection,
    folderPath,
    imageList = [],
    aveName,
    layerCount,
    aeSharePath,
    flatten,
    hasArtboard,
    exportCanceled,
    imagePath;
var webviewIdentifier = 'aeux.webview';
var existingWebview = null;
/* harmony default export */ __webpack_exports__["default"] = (function () {
  existingWebview = Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_1__["getWebview"])(webviewIdentifier);
  var theme = sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.getTheme();
  var darkMode = theme === 'dark';
  var options = {
    identifier: webviewIdentifier,
    width: 158,
    height: 212,
    titleBarStyle: 'hiddenInset',
    remembersWindowFrame: true,
    // hidesOnDeactivate: false,
    resizable: false,
    // movable: false,
    // minimizable: false,
    alwaysOnTop: true,
    show: false,
    webPreferences: {
      devTools: true
    }
  };
  var browserWindow = new sketch_module_web_view__WEBPACK_IMPORTED_MODULE_0___default.a(options);

  if (existingWebview) {
    existingWebview.webContents.executeJavaScript("flashUI(".concat(darkMode, ")"));
  } else {
    // load url
    browserWindow.loadURL(__webpack_require__(/*! ../resources/webview.html */ "./resources/webview.html"));
  } // only show the window when the page has loaded to avoid a white flash


  browserWindow.once('ready-to-show', function () {
    browserWindow.show();
  });
  var webContents = browserWindow.webContents; // print a message when the page loads

  webContents.on('did-finish-load', function () {// UI.message('UI loaded!')
  }); // add a handler for a call from web content's javascript

  webContents.on('nativeLog', function (s) {
    sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message(s);
    webContents.executeJavaScript("setRandomNumber(".concat(Math.random(), ")")).catch(console.error);
  }); // open a link

  webContents.on('externalLinkClicked', function (url) {
    NSWorkspace.sharedWorkspace().openURL(NSURL.URLWithString(url));
  }); // send layer data to Ae

  webContents.on('fetchAEUX', function (prefs) {
    // UI.alert('prefs', 'got some')
    fetchAEUX();
  }); // send layer data to Ae

  webContents.on('detachSymbols', function () {
    detachSymbols();
  }); // send layer data to Ae

  webContents.on('flattenCompounds', function () {
    flattenCompounds();
  }); // send layer data to Ae

  webContents.on('rasterizeGroups', function () {
    rasterizeGroups();
  }); // Used to debug

  webContents.on('alert', function (str) {
    sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.alert('Debug:', str);
  }); // set darkmode on launch

  webContents.executeJavaScript("setDarkMode(".concat(darkMode, ")")); // panel prefs

  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

  var aeuxPrefs = Settings.settingForKey('aeuxPrefs');
  webContents.executeJavaScript("setPrefs(".concat(aeuxPrefs, ")"));
  webContents.on('setPrefs', function (prefs) {
    Settings.setSettingForKey('aeuxPrefs', prefs);
  });
}); // When the plugin is shutdown by Sketch (for example when the user disable the plugin)
// we need to close the webview if it's open

function onShutdown() {
  existingWebview = Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_1__["getWebview"])(webviewIdentifier);

  if (existingWebview) {
    existingWebview.close();
  }
}
function fetchAEUX() {
  var existingWebview = Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_1__["getWebview"])(webviewIdentifier);
  imageList = [];
  document = __webpack_require__(/*! sketch/dom */ "sketch/dom").getSelectedDocument();
  selection = document.selectedLayers; /// reset vars
  // folderPath = null;

  hasArtboard = false;
  layerCount = 0;
  var aeuxData = filterTypes(selection);

  if (layerCount < 1) {
    existingWebview.webContents.executeJavaScript("setFooterMsg('0 layers sent to Ae')");
    return;
  }

  aeuxData[0].layerCount = layerCount; // aeuxData[0].folderPath = 6olderPath;

  console.log(aeuxData);

  if (imageList.length < 1) {
    fetch("http://127.0.0.1:7240/evalScript", {
      method: "POST",
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        method: 'buildLayers',
        data: {
          layerData: aeuxData
        },
        switch: 'aftereffects',
        getPrefs: true
      })
    }).then(function (response) {
      if (response.ok) {
        return response.json();
      } else {
        throw Error('failed to connect');
      }
    }).then(function (json) {
      // get back a message from Ae and display it at the bottom of Sketch
      console.log(json);
      var lyrs = json.layerCount;
      var msg = lyrs == 1 ? lyrs + ' layer sent to Ae' : lyrs + ' layers sent to Ae';

      if (!existingWebview) {
        // webview is closed
        sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message(msg);
      } else {
        // send something to the webview
        existingWebview.webContents.executeJavaScript("setFooterMsg('".concat(msg, "')"));
      }
    }).catch(function (e) {
      console.error(e);
      var msgToWebview = 'Unable to communicate with Ae';

      if (!existingWebview) {
        // webview is closed
        sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message(msgToWebview);
      } else {
        // send something to the webview            
        existingWebview.webContents.executeJavaScript("setFooterMsg('".concat(msgToWebview, "')"));
      }
    });
  } else {
    // save images
    console.log('Build images');
    console.log(aeuxData);
    fetch("http://127.0.0.1:7240/writeFiles", {
      method: "POST",
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        switch: 'aftereffects',
        images: imageList,
        // path: imagePath, 
        data: {
          layerData: aeuxData
        }
      })
    }).then(function (response) {
      if (response.ok) {
        return response.json();
      } else {
        throw Error('failed to connect');
      }
    }).then(function (json) {
      // get back a message from Ae and display it at the bottom of Sketch
      console.log(json);
      var lyrs = json.layerCount;
      var msg = lyrs == 1 ? lyrs + ' layer sent to Ae' : lyrs + ' layers sent to Ae';

      if (!existingWebview) {
        // webview is closed
        sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message(msg);
      } else {
        // send something to the webview
        existingWebview.webContents.executeJavaScript("setFooterMsg('".concat(msg, "')"));
      }
    }).catch(function (e) {
      var msgToWebview = 'Unable to communicate with Ae';

      if (!existingWebview) {
        // webview is closed
        sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message(msgToWebview);
      } else {
        // send something to the webview            
        existingWebview.webContents.executeJavaScript("setFooterMsg('".concat(msgToWebview, "')"));
      }
    });
  }
} //// recursivly detach symbols from masters

function detachSymbols() {
  document = __webpack_require__(/*! sketch/dom */ "sketch/dom").getSelectedDocument();
  selection = document.selectedLayers; // reset vars

  layerCount = 0;
  var layers = selection.layers; /// if an artboard is selected, process all layers inside of it

  if (layers.length > 0 && (layers[0].type == 'Artboard' || layers[0].type == 'SymbolMaster')) {
    layers = layers[0].layers;
  } /// run process


  detachChildren(layers); /// completion message

  var existingWebview = Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_1__["getWebview"])(webviewIdentifier);
  var lyrs = layerCount;
  var msg = lyrs == 1 ? lyrs + ' symbol detached' : lyrs + ' symbols detached';

  if (!existingWebview) {
    // webview is closed
    sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message(msg);
  } else {
    existingWebview.webContents.executeJavaScript("setFooterMsg('".concat(msg, "')"));
  } /// recursive func


  function detachChildren(layers) {
    for (var i = 0; i < layers.length; i++) {
      var layer = layers[i];

      if (layer.type == 'Group') {
        detachChildren(layer.layers);
      }

      if (layer.type == 'SymbolInstance') {
        // detachChildren(layer.master.layers);
        var detatchedGroup = layer.detach();

        if (detatchedGroup.layers.length < 2) {
          detatchedGroup.sketchObject.ungroup();
        }

        layerCount++;
      }
    }
  }
} //// simplify complex layers by recursivly flattening compound shapes

function flattenCompounds() {
  document = __webpack_require__(/*! sketch/dom */ "sketch/dom").getSelectedDocument();
  selection = document.selectedLayers; /// reset vars

  layerCount = 0;
  var layers = selection.layers; /// if an artboard is selected, process all layers inside of it

  if (layers.length > 0 && (layers[0].type == 'Artboard' || layers[0].type == 'SymbolMaster')) {
    layers = layers[0].layers;
  } /// run process


  flattenChildren(layers); /// completion message

  var existingWebview = Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_1__["getWebview"])(webviewIdentifier);
  var lyrs = layerCount;
  var msg = lyrs == 1 ? lyrs + ' shape flattened' : lyrs + ' shapes flattened';

  if (!existingWebview) {
    // webview is closed
    sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message(msg);
  } else {
    existingWebview.webContents.executeJavaScript("setFooterMsg('".concat(msg, "')"));
  } /// recursive func


  function flattenChildren(layers) {
    for (var i = 0; i < layers.length; i++) {
      var layer = layers[i];
      var layerType = getShapeType(layer.sketchObject);

      if (layer.type == 'Group') {
        flattenChildren(layer.layers);
      }

      if (layerType == 'CompoundShape') {
        layer.sketchObject.flatten();
        layerCount++;
      }
    }
  }
} //// recursivly detach symbols from masters

function rasterizeGroups() {
  document = __webpack_require__(/*! sketch/dom */ "sketch/dom").getSelectedDocument();
  selection = document.selectedLayers; // reset vars

  layerCount = 0;
  var layers = selection.layers; // /// if an artboard is selected, process all layers inside of it
  // if (layers.length > 0 && (layers[0].type == 'Artboard' || layers[0].type == 'SymbolMaster')) {
  //     layers = layers[0].layers;
  // }

  console.log(layers);
  layers.forEach(function (layer) {
    layer.frame;
  }); // /// run process
  // detachChildren(layers);
  /// completion message

  var existingWebview = Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_1__["getWebview"])(webviewIdentifier);
  var lyrs = layerCount;
  var msg = lyrs == 1 ? lyrs + ' group rasterized' : lyrs + ' groups rasterized';

  if (!existingWebview) {
    // webview is closed
    sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message(msg);
  } else {
    existingWebview.webContents.executeJavaScript("setFooterMsg('".concat(msg, "')"));
  } /// recursive func


  function detachChildren(layers) {
    for (var i = 0; i < layers.length; i++) {
      var layer = layers[i];

      if (layer.type == 'Group') {
        detachChildren(layer.layers);
      }

      if (layer.type == 'SymbolInstance') {
        // detachChildren(layer.master.layers);
        var detatchedGroup = layer.detach();

        if (detatchedGroup.layers.length < 2) {
          detatchedGroup.sketchObject.ungroup();
        }

        layerCount++;
      }
    }
  }
} //// get all selected layer data

function filterTypes(selection) {
  if (selection.length < 1) {
    return [{
      layerCount: 0
    }];
  } /// reset vars


  var selectedLayerInfo = [];
  var layers = selection.layers;
  var imageList = []; /// get artboard data

  if (!hasArtboard) {
    selectedLayerInfo.push(storeArtboard());
  }

  if (!hasArtboard) {
    layerCount = -2;
    return;
  } /// if an artboard is selected, process all layers inside of it


  if (layers.length > 0 && (layers[0].type == 'Artboard' || layers[0].type == 'SymbolMaster')) {
    layers = layers[0].layers;
  } /// check that the image export has not been canceled


  if (layerCount != -1) {
    /// loop through all selected layers
    for (var i = 0; i < layers.length; i++) {
      var layer = layers[i]; // skip layer if not visible

      if (!layer.sketchObject.isVisible()) {
        continue;
      } // get layer data by layer type


      if (layer.type == 'Group') {
        selectedLayerInfo.push(getGroup(layer));
        continue;
      }

      if (layer.type == 'ShapePath' || layer.type == 'Shape') {
        selectedLayerInfo.push(getShape(layer));
      }

      if (layer.type == 'SymbolInstance') {
        selectedLayerInfo.push(getSymbol(layer));
      }

      if (layer.type == 'Text') {
        selectedLayerInfo.push(getText(layer));
      }

      if (layer.type == 'Image') {
        var imgLayer = getImage(layer);

        if (imgLayer == null) {
          layerCount = -1;
          return selectedLayerInfo;
        }

        selectedLayerInfo.push(imgLayer);
      } // increment var to show on panels


      layerCount++;
    }
  }

  return selectedLayerInfo;
} //// get artboard data


function storeArtboard() {
  var artboard = selection.layers[0].getParentArtboard() || selection.layers[0] || null; /// no artboard so store generic

  if (artboard === null) {
    return {};
  }

  var bgColor = [1, 1, 1, 1];

  try {
    if (artboard.background.enabled) {
      bgColor = hexToArray(artboard.background.color);
    }
  } catch (e) {}

  var artboardObj = {
    type: 'Artboard',
    aeuxVersion: versionNumber,
    hostApp: 'Sketch',
    name: artboard.name,
    bgColor: bgColor,
    size: [artboard.frame.width, artboard.frame.height]
  }; /// tells filterTypes() this doesn't need to run again

  hasArtboard = true;
  return artboardObj;
} //// get layer data: SHAPE


function getShape(layer) {
  var layerType = getShapeType(layer.sketchObject);
  var layerData = {
    type: layerType,
    name: layer.name,
    id: layer.id,
    frame: getFrame(layer),
    fill: getFills(layer),
    stroke: getStrokes(layer),
    shadow: getShadows(layer),
    innerShadow: getInnerShadows(layer),
    isVisible: layer.sketchObject.isVisible(),
    path: getPath(layer, layer.frame),
    roundness: getRoundness(layer),
    blur: getBlur(layer.sketchObject),
    opacity: getOpacity(layer),
    rotation: -layer.sketchObject.rotation(),
    flip: getFlipMultiplier(layer),
    blendMode: getLayerBlending(layer.sketchObject.style().contextSettings().blendMode()),
    hasClippingMask: layer.sketchObject.hasClippingMask(),
    shouldBreakMaskChain: layer.sketchObject.shouldBreakMaskChain()
  }; /// if fill is an image and should return that instead of a shape

  if (layerData.fill != null && layerData.fill.type == 'Image') {
    // layerData = layerData.fill
    // return layerData.fill;
    var imageLayer = layerData.fill;
    imageLayer.hasClippingMask = true; // imageLayer.frame.x -= layerData.frame.x

    imageLayer.frame.x = layerData.frame.width / 2;
    imageLayer.frame.y = layerData.frame.height / 2;
    layerData.fill = [{
      type: 'fill',
      enabled: true,
      color: [0.5, 0.5, 0.5, 1],
      opacity: 100,
      blendMode: 1
    }];
    layerData.frame.x = layerData.frame.width / 2;
    layerData.frame.y = layerData.frame.height / 2;
    layerData.hasClippingMask = true;
    var groupData = {
      type: 'Component',
      name: "\u25BD " + layer.name,
      id: layer.id,
      frame: getFrame(layer),
      isVisible: layer.sketchObject.isVisible(),
      opacity: getOpacity(layer),
      shadow: getShadows(layer),
      innerShadow: getInnerShadows(layer),
      rotation: -layer.sketchObject.rotation(),
      blendMode: getLayerBlending(layer.sketchObject.style().contextSettings().blendMode()),
      flip: getFlipMultiplier(layer),
      // layers: [],
      layers: [layerData, imageLayer],
      hasClippingMask: layer.sketchObject.hasClippingMask(),
      shouldBreakMaskChain: layer.sketchObject.shouldBreakMaskChain()
    };
    layerData = groupData;
  } /// if shape is a compound get the shapes that make up the compound


  if (layerType == 'CompoundShape') {
    layerData.layers = getCompoundShapes(layer.layers);
    layerData.booleanOperation = layer.layers[0].sketchObject.booleanOperation();
  }

  return layerData; // output a string of the collected data
  /// get corner roundness clamped to the shape size

  function getRoundness(layer) {
    try {
      var lyr = layer.sketchObject;
      var radius = lyr.points()[0].cornerRadius();
      var width = lyr.frame().width();
      var height = lyr.frame().height();
      var maxRad = Math.min(Math.min(width, height), radius);
      return maxRad;
    } catch (e) {
      return null;
    }
  }
} //// get layer data: SYMBOL


function getSymbol(layer) {
  // check if the symbol is an image override
  // if (layer.overrides.length > 0 &&
  //     layer.overrides[0].property == 'image' &&
  //     !layer.overrides[0].isDefault) {
  //     var imageLayer = getImage(layer);
  //     return imageLayer;
  // }
  if (layer.master == null) {
    return {};
  } // skip if layer missing


  var layerData = {
    type: 'Symbol',
    name: layer.master.name,
    masterId: layer.master.id,
    id: layer.id,
    frame: getFrame(layer),
    style: layer.style,
    isVisible: layer.sketchObject.isVisible(),
    opacity: getOpacity(layer),
    shadow: getShadows(layer),
    innerShadow: getInnerShadows(layer),
    blendMode: getLayerBlending(layer.sketchObject.style().contextSettings().blendMode()),
    layers: filterTypes(layer.master),
    symbolFrame: layer.master.frame,
    bgColor: sketchColorToArray(layer.master.sketchObject.backgroundColor()),
    rotation: -layer.sketchObject.rotation(),
    flip: getFlipMultiplier(layer),
    hasClippingMask: layer.sketchObject.hasClippingMask(),
    shouldBreakMaskChain: layer.sketchObject.shouldBreakMaskChain()
  };
  getOverrides(layer, layerData);
  return layerData; /// get text and nested symbol overrides

  function getOverrides(layer, symbolObj) {
    // reset vars
    var overrideList = [];
    var overrides = layer.overrides; // loop through each override on the layer

    for (var i = 0; i < overrides.length; i++) {
      var override = overrides[i];

      if (!override.isDefault) {
        // has an override
        symbolObj.id = 'override';
        symbolObj.masterId = 'override'; // DEPRECIATED forced symbol detach
        // if (override.property == 'image') {     // needs to be detatched from master
        //     var detatchedGroup = layer.detach();
        //     overrideList = [];                  // reset the list
        //     i = 0;                              // reset the count
        // }
        // loop through all layers in the symbol

        for (var j = 0; j < symbolObj.layers.length; j++) {
          var currentLayer = symbolObj.layers[j]; //// it is a GROUP ////    recurse deeper

          if (currentLayer.type == 'Group') {
            getOverrides(layer, currentLayer);
            continue;
          } //// it is a SYMBOL ////


          if (override.symbolOverride) {
            if (currentLayer.id == override.path) {
              // do ids match?
              var overrideSymbol = document.getSymbolMasterWithID(override.value);

              if (overrideSymbol == undefined) {
                return;
              }

              currentLayer.name = overrideSymbol.name;
              currentLayer.masterId = overrideSymbol.id;
              currentLayer.layers = filterTypes(overrideSymbol);
            }
          } //// it is TEXT ////


          if (currentLayer.id == override.path) {
            // do ids match?
            var text = override.value;

            try {
              var transformVal = document.getLayerWithID(override.path).sketchObject.styleAttributes()["MSAttributedStringTextTransformAttribute"];

              if (transformVal == 1) {
                text = text.toUpperCase();
              }

              if (transformVal == 2) {
                text = text.toLowerCase();
              }
            } catch (e) {}

            currentLayer[override.property] = text; // replace the text/image value
          }
        }
      }
    }
  }
} //// get layer data: GROUP


function getGroup(layer) {
  var flip = getFlipMultiplier(layer);
  var layerData = {
    type: 'Group',
    name: "\u25BD " + layer.name,
    id: layer.id,
    frame: getFrame(layer),
    isVisible: layer.sketchObject.isVisible(),
    opacity: getOpacity(layer),
    shadow: getShadows(layer),
    innerShadow: getInnerShadows(layer),
    rotation: -layer.sketchObject.rotation() * (flip[0] / 100) * (flip[1] / 100),
    blendMode: layer.sketchObject.style().contextSettings().blendMode(),
    flip: flip,
    hasClippingMask: layer.sketchObject.hasClippingMask(),
    shouldBreakMaskChain: layer.sketchObject.shouldBreakMaskChain(),
    layers: filterTypes(layer)
  }; // UI.alert('layerData', JSON.stringify(layerData.layers[0].hasClippingMask, false, 2))

  if (layerData.layers[0].hasClippingMask) {
    layerData.type = 'Component';
  }

  return layerData;
} //// get layer data: TEXT


function getText(layer) {
  /// reset vars
  var kind;
  var frame = {}; /// is the layer flipped?

  var flip = getFlipMultiplier(layer); /// point or area text box

  if (layer.sketchObject.textBehaviour() == 0) {
    kind = 'Point';
    frame = {
      x: layer.frame.x,
      y: layer.frame.y + layer.sketchObject.glyphBounds().origin.y,
      width: layer.frame.width,
      height: layer.frame.height
    };
  } else {
    kind = 'Area';
    frame = {
      x: layer.frame.x + layer.frame.width / 2,
      y: layer.frame.y + layer.frame.height / 2 + layer.sketchObject.glyphBounds().origin.y,
      width: layer.frame.width,
      height: layer.frame.height
    };
  }

  var layerData = {
    type: 'Text',
    kind: kind,
    name: layer.name,
    stringValue: getTextString(layer),
    id: layer.id,
    frame: frame,
    isVisible: layer.sketchObject.isVisible(),
    opacity: getOpacity(layer),
    shadow: getShadows(layer),
    innerShadow: getInnerShadows(layer),
    textColor: sketchColorToArray(layer.sketchObject.textColor()),
    fill: getFills(layer),
    stroke: getStrokes(layer),
    blendMode: getLayerBlending(layer.sketchObject.style().contextSettings().blendMode()),
    fontName: getFontName(),
    fontSize: layer.sketchObject.fontSize(),
    trackingAdjusted: layer.sketchObject.kerning() / layer.sketchObject.fontSize() * 1000,
    tracking: layer.sketchObject.kerning(),
    justification: layer.sketchObject.textAlignment(),
    lineHeight: layer.sketchObject.paragraphStyle().minimumLineHeight() || null,
    flip: flip,
    rotation: -layer.sketchObject.rotation() * (flip[0] / 100) * (flip[1] / 100),
    blur: getBlur(layer.sketchObject),
    hasClippingMask: layer.sketchObject.hasClippingMask(),
    shouldBreakMaskChain: layer.sketchObject.shouldBreakMaskChain()
  };
  return layerData;

  function getFontName() {
    var fontName = layer.sketchObject.font().fontName() + '0';
    return fontName.slice(0, -1);
  }

  function getTextString(layer) {
    var text = layer.text.replace(/[\u2028]/g, '\n');
    var transformVal = 0;
    var transformVal = layer.sketchObject.styleAttributes()["MSAttributedStringTextTransformAttribute"];

    if (transformVal == 1) {
      text = text.toUpperCase();
    }

    if (transformVal == 2) {
      text = text.toLowerCase();
    }

    return text;
  }
} //// get layer data: IMAGE


function getImage(layer, filldata) {
  try {
    var layerData = {
      type: 'Image',
      name: layer.name,
      id: layer.id,
      frame: getFrame(layer),
      isVisible: !layer.hidden,
      opacity: getOpacity(layer),
      blendMode: getLayerBlending(layer.style.blendMode),
      rotation: -layer.transform.rotation,
      hasClippingMask: layer.sketchObject.hasClippingMask(),
      shouldBreakMaskChain: layer.sketchObject.shouldBreakMaskChain()
    }; // UI.alert('filldata', JSON.stringify(filldata, false, 2))
    // UI.alert('layerData', JSON.stringify(layerData, false, 2))

    var imgData = '';

    if (layer.image) {
      if (layer.image.nsimage.toString().search('NSBitmapImageRep') != -1) {
        imgData = layer.image.nsdata.base64EncodedStringWithOptions(0).toString();
      }
    } else {
      // var sizeMult = 1
      // UI.message(filldata.size.width)
      // if (layerData.frame.width >= layerData.frame.height) {
      //     sizeMult = layerData.frame.width / filldata.size.width
      // } else {
      //     sizeMult = layerData.frame.height / filldata.size.height
      // }
      // layerData.frame.width = filldata.size.width * sizeMult
      // layerData.frame.height = filldata.size.height * sizeMult
      imgData = filldata.nsdata.base64EncodedStringWithOptions(0).toString();
    }

    imageList.push({
      name: "".concat(layerData.name, "_").concat(layerData.id, ".png"),
      imgData: "".concat(imgData.replace(/<|>/g, ''))
    });
    console.log(imageList);
    return layerData;
  } catch (error) {
    sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.alert('error', error);
  }
} //// get layer data: COMPOUND SHAPE


function getCompoundShapes(layers) {
  var layerList = []; /// loop through all nested shapes

  for (var i = 0; i < layers.length; i++) {
    var layer = layers[i];
    var layerType = getCompoundShapeType(layer.sketchObject); // var layerId = (layer.objectID()+ '&').slice(0, -1);

    var flip = getFlipMultiplier(layer);
    var frame = {
      x: layer.frame.x,
      y: layer.frame.y,
      width: layer.frame.width,
      height: layer.frame.height
    };
    layerList.push({
      type: layerType,
      name: layer.name,
      id: layer.id,
      frame: frame,
      isVisible: !layer.hidden,
      path: getPath(layer, frame),
      roundness: getCompoundRoundness(layer.sketchObject),
      flip: flip,
      rotation: -layer.sketchObject.rotation() * (flip[0] / 100) * (flip[1] / 100),
      booleanOperation: layer.sketchObject.booleanOperation()
    });

    if (layerType == 'CompoundShape') {
      layerList[i].layers = getCompoundShapes(layer.layers);
    }
  }

  return layerList; /// check the shape type

  function getCompoundShapeType(lyr) {
    if (lyr.class() == 'MSRectangleShape' && !lyr.edited()) {
      return 'Rect';
    }

    if (lyr.class() == 'MSOvalShape' && !lyr.edited()) {
      return 'Ellipse';
    }

    if (lyr.class() == 'MSShapeGroup' && lyr.layers().length > 1) {
      // alert(JSON.stringify(getCompoundShapes(lyr.layers()), false, 2))
      // layerList[i].layers = getCompoundShapes(layer.layers);
      return 'CompoundShape';
    }

    return 'Path';
  } /// get corner roundness clamped to the shape size


  function getCompoundRoundness(layer) {
    try {
      var radius = layer.fixedRadius();
      var width = layer.frame().width();
      var height = layer.frame().height();
      var maxRad = Math.min(Math.min(width, height), radius);
      return maxRad / 2;
    } catch (e) {
      return null;
    }
  }
} //// get shape data: PATH


function getPath(layer, frame) {
  // var lyr = layer.sketchObject.layers().firstObject();     // 51
  var lyr = layer.sketchObject; // skip if no path on the current object (like a compound path )

  if (!lyr.points) {
    return {
      points: [],
      inTangents: [],
      outTangents: [],
      closed: false
    };
  } /// reset vars


  var points = [],
      inTangents = [],
      outTangents = []; /// get the path object

  var path = lyr.points(); /// get the height and width to multiply point point coordinates

  var shapeSize = {
    w: frame.width,
    h: frame.height
  }; /// loop through each point on the path

  for (var k = 0; k < path.length; k++) {
    // paths are normalized to 0-1 and scaled by a height and width multiplier
    var p = [round100(path[k].point().x * shapeSize.w), round100(path[k].point().y * shapeSize.h)]; // if the current point has curves and needs tangent handles

    if (path[k].curveMode() !== 1) {
      // tangent out of the point offset by the point coordinates onscreen
      var o = [round100(path[k].curveFrom().x * shapeSize.w - p[0]), round100(path[k].curveFrom().y * shapeSize.h - p[1])]; // tangent into the point offset by the point coordinates onscreen

      var i = [round100(path[k].curveTo().x * shapeSize.w - p[0]), round100(path[k].curveTo().y * shapeSize.h - p[1])]; // current point has no curves so tangets are at the same coordinate as the point
    } else {
      var o = [0, 0];
      var i = [0, 0];
    } // add current point and tangent with screen dimensions


    points.push(p);
    inTangents.push(i);
    outTangents.push(o);
  } // create object to store path data


  var pathObj = {
    points: points,
    inTangents: inTangents,
    outTangents: outTangents,
    closed: lyr.isClosed() == 1
  };
  return pathObj;
} //// get layer data: OPACITY


function getOpacity(layer) {
  return Math.round(layer.style.opacity * 100);
} //// get layer data: SHAPE TYPE


function getShapeType(lyr) {
  if (lyr.class() == 'MSShapeGroup' && lyr.layers().length > 1) {
    return 'CompoundShape';
  }

  if (lyr.class() == 'MSRectangleShape' && !lyr.edited()) {
    return 'Rect';
  }

  if (lyr.class() == 'MSOvalShape' && !lyr.edited()) {
    return 'Ellipse';
  }

  try {
    if (lyr.layers().firstObject().class() == 'MSRectangleShape' && !lyr.layers()[0].edited()) {
      return 'Rect';
    }

    if (lyr.layers().firstObject().class() == 'MSOvalShape' && !lyr.layers()[0].edited()) {
      return 'Ellipse';
    }
  } catch (e) {}

  return 'Path';
} //// get layer data: FLIP


function getFlipMultiplier(layer) {
  try {
    var x = layer.sketchObject.isFlippedHorizontal() ? -100 : 100;
    var y = layer.sketchObject.isFlippedVertical() ? -100 : 100;
  } catch (e) {
    var x = layer.isFlippedHorizontal() ? -100 : 100;
    var y = layer.isFlippedVertical() ? -100 : 100;
  }

  return [x, y];
} //// get layer data: FILL


function getFills(layer) {
  /// get layer style object
  // var style = layer.sketchObject.style();
  var style = layer.style; /// check if the layer has at least one fill

  var hasFill = style.fills.length > 0 ? true : false;

  if (hasFill) {
    var fillData = [];
    var size = [layer.frame.width, layer.frame.height]; // loop through all fills

    for (var i = 0; i < style.fills.length; i++) {
      var fill = style.fills[i]; // add fill to fillProps only if fill is enabled

      if (fill.enabled) {
        // fill is a gradient
        if (fill.fillType == 'Gradient') {
          // UI.alert('gradient', JSON.stringify(fill.gradient.gradientType == 'Radial' ))
          var color = hexToArray(fill.color);
          var fillObj = {
            type: 'gradient',
            startPoint: [fill.gradient.from.x * size[0] - layer.frame.width / 2, fill.gradient.from.y * size[1] - layer.frame.height / 2],
            endPoint: [fill.gradient.to.x * size[0] - layer.frame.width / 2, fill.gradient.to.y * size[1] - layer.frame.height / 2],
            gradType: fill.gradient.gradientType == 'Radial' ? 2 : 1,
            gradient: getGradient(fill.gradient.stops),
            opacity: Math.round(color[3] * 100),
            blendMode: getShapeBlending(layer.sketchObject.style().fills()[i].contextSettings().blendMode())
          }; // fill is an image or texture
        } else if (fill.fillType == 'Pattern') {
          // UI.alert('debug', JSON.stringify(fill, false, 2))
          fillData = getImage(layer, fill.pattern.image);
          break; // fill is a solid
        } else {
          var color = hexToArray(fill.color);
          var fillObj = {
            type: 'fill',
            enabled: fill.enabled,
            color: color,
            opacity: Math.round(color[3] * 100),
            blendMode: getShapeBlending(layer.sketchObject.style().fills()[i].contextSettings().blendMode())
          };
        } // UI.alert('gradient', JSON.stringify(fillObj, false, 2))
        // add obj string to array


        fillData.push(fillObj);
      }
    }

    return fillData;
  } else {
    return null;
  }
} //// get layer data: STROKE


function getStrokes(layer) {
  /// get layer style object
  var style = layer.sketchObject.style();
  var styleJs = layer.style; /// check if the layer has at least one stroke

  var hasStroke = styleJs.borders.length > 0 ? true : false;

  if (hasStroke) {
    var strokeData = [];
    var size = [layer.frame.width, layer.frame.height]; // loop through all strokes

    for (var i = 0; i < style.borders().length; i++) {
      var border = style.borders()[i];
      var borderJs = styleJs.borders[i];

      if (borderJs.enabled) {
        var color = hexToArray(borderJs.color); // stroke is a gradient

        if (border.fillType() == 1) {
          var strokeObj = {
            type: 'gradient',
            startPoint: [borderJs.gradient.from.x * size[0] - layer.frame.width / 2, borderJs.gradient.from.y * size[1] - layer.frame.height / 2],
            endPoint: [borderJs.gradient.to.x * size[0] - layer.frame.width / 2, borderJs.gradient.to.y * size[1] - layer.frame.height / 2],
            gradType: borderJs.gradient.gradientType == 'Radial' ? 2 : 1,
            gradient: getGradient(borderJs.gradient.stops),
            opacity: color[3] * 100,
            width: borderJs.thickness,
            cap: style.borderOptions().lineCapStyle(),
            join: style.borderOptions().lineJoinStyle(),
            strokeDashes: style.borderOptions().dashPattern(),
            blendMode: getShapeBlending(border.contextSettings().blendMode())
          }; // stroke is a solid
        } else {
          var strokeObj = {
            type: 'fill',
            enabled: borderJs.enabled,
            color: color,
            opacity: color[3] * 100,
            width: borderJs.thickness,
            cap: style.borderOptions().lineCapStyle(),
            join: style.borderOptions().lineJoinStyle(),
            strokeDashes: getDashes(style.borderOptions()),
            blendMode: getShapeBlending(border.contextSettings().blendMode())
          };
        } // add obj string to array


        strokeData.push(strokeObj);
      }
    }

    return strokeData; // return array of all strokes
  } else {
    return null; // no fills so return null
  }
} //// get layer data: STROKE DASHES


function getDashes(borderOptions) {
  var dashPattern = borderOptions.dashPattern();
  var dashArray = [];

  for (var i = 0; i < dashPattern.length; i++) {
    var str = (dashPattern[i] + '&').slice(0, -1);
    dashArray.push(parseFloat(str));
  }

  return dashArray;
} //// get layer data: GRADIENT


function getGradient(grad) {
  var gradObj = {
    length: grad.length,
    points: []
  };

  for (var i = 0; i < gradObj.length; i++) {
    var colorArr = hexToArray(grad[i].color);
    gradObj.points.push({
      color: colorArr,
      midPoint: 0.5,
      opacity: colorArr[3],
      rampPoint: grad[i].position
    });
  }

  return gradObj;
} //// get layer data: DROP SHADOW


function getShadows(layer) {
  var style = layer.sketchObject.style();
  var hasShadow = style.firstEnabledShadow() ? true : false;

  if (hasShadow) {
    var shadowData = []; // array to store shadow(s)

    for (var i = 0; i < style.shadows().length; i++) {
      // loop through all shadows
      var shadow = style.shadows()[i];

      if (shadow.isEnabled()) {
        // add shadow to shadowProps only if shadow is enabled
        var shadowObj = {
          // 1 object per shadow obj
          color: sketchColorToArray(shadow.color()),
          // store color obj as array
          position: [shadow.offsetX(), shadow.offsetY()],
          blur: shadow.blurRadius(),
          spread: shadow.spread()
        };
        shadowData.push(shadowObj); // add obj string to array
      }
    }

    return shadowData; // return array of all shadows
  } else {
    return null; // no shadows so return null
  }
} //// get layer data: INNER SHADOW


function getInnerShadows(layer) {
  var style = layer.sketchObject.style();
  var hasShadow = style.innerShadows().length > 0 && style.innerShadows()[0].isEnabled() ? true : false; // check if the layer has at least one drop shadow

  if (hasShadow) {
    var shadowData = []; // array to store shadow(s)

    for (var i = 0; i < style.innerShadows().length; i++) {
      // loop through all shadows
      var innerShadow = style.innerShadows()[i];
      var shadowObj = {
        // 1 object per shadow obj
        color: sketchColorToArray(innerShadow.color()),
        // store color obj as array
        position: [innerShadow.offsetX(), innerShadow.offsetY()],
        blur: innerShadow.blurRadius(),
        spread: innerShadow.spread()
      };
      shadowData.push(shadowObj); // add obj string to array
    }

    return shadowData; // return array of all shadows
  } else {
    return null; // no shadows so return null
  }
} //// get layer data: BLUR


function getBlur(layer) {
  var blur = layer.style().blur();

  if (!blur.isEnabled()) {
    return null;
  }

  var blurObj = {
    // center: blur.center(),
    direction: (90 - blur.motionAngle()) % 360,
    radius: blur.radius() * 4,
    type: blur.type()
  };
  return [blurObj];
} //// DEPRECIATED copy text to clipboard
// function copy_text(txt){
//     var pasteBoard = NSPasteboard.generalPasteboard();
// 		pasteBoard.clearContents();
// 		pasteBoard.declareTypes_owner(NSArray.arrayWithObject(NSPasteboardTypeString), null);
//         pasteBoard.setString_forType(txt, NSPasteboardTypeString);
// }
//// save data to text file


function save_text(text, filePath) {
  var t = NSString.stringWithFormat("%@", text);
  var f = NSString.stringWithFormat("%@", filePath);
  return t.writeToFile_atomically_encoding_error(f, true, NSUTF8StringEncoding, null);
} //// open dialog and return path


function getFolderPath() {
  if (exportCanceled) {
    return false;
  } // cancel the process


  if (folderPath == null) {
    var saveWindow = NSOpenPanel.openPanel();
    saveWindow.setCanCreateDirectories(true);
    saveWindow.setCanChooseDirectories(true);
    saveWindow.setCanChooseFiles(false);
    saveWindow.setPrompt('Select');
    saveWindow.setMessage('Location to save images');
    var pathSaved = saveWindow.runModal();

    if (pathSaved) {
      folderPath = decodeURI(saveWindow.URLs().objectAtIndex(0));
      folderPath = folderPath.replace('file://', ''); // remove the file://

      return true; // folder path found
    }

    exportCanceled = true; // canceled

    return false;
  }

  return true; // folder path exists
} //// save dialog and return path


function getSavePath() {
  if (exportCanceled) {
    return false;
  } // cancel the process


  if (folderPath == null) {
    var saveWindow = NSSavePanel.savePanel();
    saveWindow.setCanCreateDirectories(true);
    saveWindow.setCanChooseDirectories(true);
    saveWindow.setCanChooseFiles(false);
    saveWindow.setPrompt('Select');
    saveWindow.setMessage('Location to save json file and any images');
    saveWindow.nameFieldStringValue = toolName + '.json'; // saveWindow.allowedFileTypes(['json']);

    var pathSaved = saveWindow.runModal();

    if (pathSaved) {
      folderPath = decodeURI(saveWindow.URLs().objectAtIndex(0));
      folderPath = folderPath.replace('file://', ''); // remove the file://

      saveName = saveWindow.nameFieldStringValue();
      return true; // folder path found
    }

    exportCanceled = true; // canceled

    return false;
  }

  return true; // folder path exists
} //// rearrange origin of a shape


function getFrame(layer) {
  var frame = layer.frame;
  return {
    width: frame.width,
    height: frame.height,
    x: frame.x + frame.width / 2,
    y: frame.y + frame.height / 2
  };
} //// reduce math resolution


function round100(num) {
  return Math.round(num * 100) / 100;
} //// return enumerated layer blending mode


function getLayerBlending(mode) {
  var aeBlendMode;

  switch (mode) {
    case 1:
      aeBlendMode = 'BlendingMode.DARKEN';
      break;

    case 2:
      aeBlendMode = 'BlendingMode.MULTIPLY';
      break;

    case 3:
      aeBlendMode = 'BlendingMode.COLOR_BURN';
      break;

    case 4:
      aeBlendMode = 'BlendingMode.LIGHTEN';
      break;

    case 5:
      aeBlendMode = 'BlendingMode.SCREEN';
      break;

    case 6:
      aeBlendMode = 'BlendingMode.ADD';
      break;

    case 7:
      aeBlendMode = 'BlendingMode.OVERLAY';
      break;

    case 8:
      aeBlendMode = 'BlendingMode.SOFT_LIGHT';
      break;

    case 9:
      aeBlendMode = 'BlendingMode.HARD_LIGHT';
      break;

    case 10:
      aeBlendMode = 'BlendingMode.DIFFERENCE';
      break;

    case 11:
      aeBlendMode = 'BlendingMode.EXCLUSION';
      break;

    case 12:
      aeBlendMode = 'BlendingMode.HUE';
      break;

    case 13:
      aeBlendMode = 'BlendingMode.SATURATION';
      break;

    case 14:
      aeBlendMode = 'BlendingMode.COLOR';
      break;

    case 15:
      aeBlendMode = 'BlendingMode.LUMINOSITY';
      break;

    default:
      aeBlendMode = 'BlendingMode.NORMAL';
  }

  return aeBlendMode;
} //// return integer layer blending mode


function getShapeBlending(mode) {
  var aeBlendMode;

  switch (mode) {
    case 1:
      aeBlendMode = 3;
      break;

    case 2:
      aeBlendMode = 4;
      break;

    case 3:
      aeBlendMode = 5;
      break;

    case 4:
      aeBlendMode = 9;
      break;

    case 5:
      aeBlendMode = 10;
      break;

    case 6:
      aeBlendMode = 11;
      break;

    case 7:
      aeBlendMode = 15;
      break;

    case 8:
      aeBlendMode = 16;
      break;

    case 9:
      aeBlendMode = 17;
      break;

    case 10:
      aeBlendMode = 23;
      break;

    case 11:
      aeBlendMode = 24;
      break;

    case 12:
      aeBlendMode = 26;
      break;

    case 13:
      aeBlendMode = 27;
      break;

    case 14:
      aeBlendMode = 28;
      break;

    case 15:
      aeBlendMode = 29;
      break;

    default:
      aeBlendMode = 1;
  }

  return aeBlendMode;
} //// convert color obj to array


function sketchColorToArray(c) {
  var colorString = c.toString().replace('r:', '').replace('g:', '').replace('b:', '').replace('a:', '').replace(/\s/g, ', ').replace('(', '[').replace(')', ']');
  return JSON.parse(colorString);
} //// convert hex color to array


function hexToArray(hexString) {
  var hexColor = hexString.replace('#', '');
  var r = parseInt(hexColor.slice(0, 2), 16) / 255,
      g = parseInt(hexColor.slice(2, 4), 16) / 255,
      b = parseInt(hexColor.slice(4, 6), 16) / 255,
      a = hexColor.length > 6 ? parseInt(hexColor.slice(6, 8), 16) / 255 : 1;
  return [r, g, b, a];
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default');
globalThis['onShutdown'] = __skpm_run.bind(this, 'onShutdown');
globalThis['fetchAEUX'] = __skpm_run.bind(this, 'fetchAEUX');
globalThis['detachSymbols'] = __skpm_run.bind(this, 'detachSymbols');
globalThis['flattenCompounds'] = __skpm_run.bind(this, 'flattenCompounds')

//# sourceMappingURL=__plugin.js.map